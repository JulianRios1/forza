SET FOREIGN_KEY_CHECKS = 0;

-- 
-- Table structure for table `agendas` 
-- 

DROP TABLE IF EXISTS `agendas`;
CREATE TABLE `agendas` (
`id` int(11) NOT NULL auto_increment,
`medico` varchar(255) DEFAULT NULL,
`dia` int(11) DEFAULT NULL,
`mes` int(255) DEFAULT NULL,
`ano` int(255) DEFAULT NULL,
`hor_ini` varchar(11) DEFAULT NULL,
`min_ini` varchar(11) DEFAULT NULL,
`vendedor` varchar(255) NOT NULL,
`estado` int(11) DEFAULT '0',
`observacion` text DEFAULT NULL,
`observacionDir` text DEFAULT NULL,
`color` varchar(50) DEFAULT NULL,
`inicio` datetime NOT NULL,
`fin` datetime DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12783;

-- --------------------------------------------------------

-- 
-- Table structure for table `archivos_cargados` 
-- 

DROP TABLE IF EXISTS `archivos_cargados`;
CREATE TABLE `archivos_cargados` (
`id` int(11) NOT NULL auto_increment,
`descripcion` varchar(255) DEFAULT NULL,
`fecha` date DEFAULT NULL,
`hora` time DEFAULT NULL,
`ano` int(11) DEFAULT NULL,
`mes` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=412;

-- --------------------------------------------------------

-- 
-- Table structure for table `banners` 
-- 

DROP TABLE IF EXISTS `banners`;
CREATE TABLE `banners` (
`id` int(11) NOT NULL auto_increment,
`nombre` varchar(255) DEFAULT NULL,
`imagen` varchar(255) DEFAULT NULL,
`link` varchar(255) DEFAULT NULL,
`fijo` int(11) DEFAULT '0',
`estado` int(11) DEFAULT '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14;

-- --------------------------------------------------------

-- 
-- Table structure for table `bitacora` 
-- 

DROP TABLE IF EXISTS `bitacora`;
CREATE TABLE `bitacora` (
`id` int(11) NOT NULL auto_increment,
`descripcion` text DEFAULT NULL,
`fecha` date DEFAULT NULL,
`hora` time DEFAULT NULL,
`usuario_registro` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_bitacora_usuarios` (`usuario_registro`)
) ENGINE=InnoDB AUTO_INCREMENT=1;

-- --------------------------------------------------------

-- 
-- Table structure for table `bitacora_acceso` 
-- 

DROP TABLE IF EXISTS `bitacora_acceso`;
CREATE TABLE `bitacora_acceso` (
`id` int(11) NOT NULL auto_increment,
`usuario_id` int(11) DEFAULT NULL,
`ip` varchar(50) DEFAULT NULL,
`terminal` varchar(50) DEFAULT NULL,
`fecha` datetime DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_bitacora_acceso_usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=572;

-- --------------------------------------------------------

-- 
-- Table structure for table `cartera_usuarios` 
-- 

DROP TABLE IF EXISTS `cartera_usuarios`;
CREATE TABLE `cartera_usuarios` (
`id` int(11) NOT NULL auto_increment,
`cliente_doc` varchar(255) DEFAULT NULL,
`mes` int(11) DEFAULT NULL,
`ano` int(11) DEFAULT NULL,
`compra` int(11) DEFAULT NULL,
`pago` int(11) DEFAULT NULL,
`descuento` int(11) DEFAULT NULL,
`retefuente` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `compra` (`compra`)
) ENGINE=InnoDB AUTO_INCREMENT=63397;

-- --------------------------------------------------------

-- 
-- Table structure for table `casos_clinicos` 
-- 

DROP TABLE IF EXISTS `casos_clinicos`;
CREATE TABLE `casos_clinicos` (
`id` int(11) NOT NULL auto_increment,
`clasificacion` int(11) DEFAULT NULL,
`titulo` varchar(255) DEFAULT NULL,
`nombrePaciente` varchar(255) DEFAULT NULL,
`edad` varchar(255) DEFAULT NULL,
`raza` varchar(255) DEFAULT NULL,
`color` varchar(255) DEFAULT NULL,
`sexo` varchar(255) DEFAULT NULL,
`peso` varchar(255) DEFAULT NULL,
`medico` varchar(255) DEFAULT NULL,
`motivo` text DEFAULT NULL,
`examen` text DEFAULT NULL,
`observaciones` text DEFAULT NULL,
`diagnostico` text DEFAULT NULL,
`medicamentos_alo` text DEFAULT NULL,
`medicamentos_zoo` text DEFAULT NULL,
`evolucion` text DEFAULT NULL,
`conclusiones` text DEFAULT NULL,
`fecha` date DEFAULT NULL,
`estado` int(11) DEFAULT '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10;

-- --------------------------------------------------------

-- 
-- Table structure for table `casos_clinicos_ayudas` 
-- 

DROP TABLE IF EXISTS `casos_clinicos_ayudas`;
CREATE TABLE `casos_clinicos_ayudas` (
`id` int(11) NOT NULL auto_increment,
`caso_fk` int(11) NOT NULL,
`imagen` varchar(255) DEFAULT NULL,
`observacion` text DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `casos_clinicos_ayudas_ibfk_1` (`caso_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=16;

-- --------------------------------------------------------

-- 
-- Table structure for table `casos_clinicos_datos` 
-- 

DROP TABLE IF EXISTS `casos_clinicos_datos`;
CREATE TABLE `casos_clinicos_datos` (
`id` int(11) NOT NULL auto_increment,
`cantidad1` int(11) DEFAULT NULL,
`porcentaje1` int(11) DEFAULT NULL,
`cantidad2` int(11) DEFAULT NULL,
`porcentaje2` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2;

-- --------------------------------------------------------

-- 
-- Table structure for table `casos_clinicos_enlaces` 
-- 

DROP TABLE IF EXISTS `casos_clinicos_enlaces`;
CREATE TABLE `casos_clinicos_enlaces` (
`id` int(11) NOT NULL auto_increment,
`caso_fk` int(11) DEFAULT NULL,
`enlace` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24;

-- --------------------------------------------------------

-- 
-- Table structure for table `casos_clinicos_imagenes` 
-- 

DROP TABLE IF EXISTS `casos_clinicos_imagenes`;
CREATE TABLE `casos_clinicos_imagenes` (
`id` int(11) NOT NULL auto_increment,
`caso_fk` int(11) DEFAULT NULL,
`imagen` varchar(255) DEFAULT NULL,
`tipo` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34;

-- --------------------------------------------------------

-- 
-- Table structure for table `casos_clinicos_votacion` 
-- 

DROP TABLE IF EXISTS `casos_clinicos_votacion`;
CREATE TABLE `casos_clinicos_votacion` (
`id` int(11) NOT NULL auto_increment,
`personal_fk` varchar(255) DEFAULT NULL,
`caso_fk` int(11) DEFAULT NULL,
`fecha` date DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20;

-- --------------------------------------------------------

-- 
-- Table structure for table `categorias` 
-- 

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
`idcategoria` int(5) unsigned NOT NULL auto_increment,
`descategoria` varchar(100) NOT NULL,
`linea` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`idcategoria`),
  UNIQUE KEY `categoria_UNIQUE1` (`descategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=31;

-- --------------------------------------------------------

-- 
-- Table structure for table `cierre_caja` 
-- 

DROP TABLE IF EXISTS `cierre_caja`;
CREATE TABLE `cierre_caja` (
`id` int(11) NOT NULL auto_increment,
`saldo_anterior` int(11) DEFAULT NULL,
`ingresos` int(11) DEFAULT NULL,
`egresos` int(11) DEFAULT NULL,
`consignaciones` int(11) DEFAULT NULL,
`saldo` int(11) DEFAULT NULL,
`estado` int(11) DEFAULT NULL,
`fecha_cierre` date DEFAULT NULL,
`sede` int(11) DEFAULT NULL,
`personal_fk` varchar(200) DEFAULT NULL,
`validado` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1707;

-- --------------------------------------------------------

-- 
-- Table structure for table `cierre_caja_farma` 
-- 

DROP TABLE IF EXISTS `cierre_caja_farma`;
CREATE TABLE `cierre_caja_farma` (
`id` int(11) NOT NULL auto_increment,
`saldo_anterior` int(11) DEFAULT NULL,
`ingresos` int(11) DEFAULT NULL,
`egresos` int(11) DEFAULT NULL,
`consignaciones` int(11) DEFAULT NULL,
`saldo` int(11) DEFAULT NULL,
`estado` int(11) DEFAULT NULL,
`fecha_cierre` date DEFAULT NULL,
`sede` int(11) DEFAULT NULL,
`personal_fk` varchar(200) DEFAULT NULL,
`validado` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1119;

-- --------------------------------------------------------

-- 
-- Table structure for table `cierre_caja_medios` 
-- 

DROP TABLE IF EXISTS `cierre_caja_medios`;
CREATE TABLE `cierre_caja_medios` (
`id` int(11) NOT NULL auto_increment,
`saldo_anterior` int(11) DEFAULT NULL,
`ingresos` int(11) DEFAULT NULL,
`egresos` int(11) DEFAULT NULL,
`consignaciones` int(11) DEFAULT NULL,
`saldo` int(11) DEFAULT NULL,
`estado` int(11) DEFAULT NULL,
`fecha_cierre` date DEFAULT NULL,
`sede` int(11) DEFAULT NULL,
`personal_fk` varchar(200) DEFAULT NULL,
`validado` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1113;

-- --------------------------------------------------------

-- 
-- Table structure for table `datos_basicos_empresa` 
-- 

DROP TABLE IF EXISTS `datos_basicos_empresa`;
CREATE TABLE `datos_basicos_empresa` (
`nit` varchar(100) NOT NULL,
`razon_social` varchar(255) NOT NULL,
`representante` varchar(255) NOT NULL,
`documento` varchar(255) NOT NULL,
`direccion` varchar(255) NOT NULL,
`telefono` varchar(255) NOT NULL,
`web` varchar(255) DEFAULT '',
`logo` varchar(255) DEFAULT '',
`correo_saliente` varchar(255) DEFAULT NULL,
`ciudad` int(11) DEFAULT NULL,
  PRIMARY KEY  (`nit`),
  KEY `FK_datos_basicos_empresa_municipios` (`ciudad`)
) ENGINE=InnoDB;

-- --------------------------------------------------------

-- 
-- Table structure for table `departamentos` 
-- 

DROP TABLE IF EXISTS `departamentos`;
CREATE TABLE `departamentos` (
`id` int(11) NOT NULL,
`nombre_dep` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB;

-- --------------------------------------------------------

-- 
-- Table structure for table `documentos` 
-- 

DROP TABLE IF EXISTS `documentos`;
CREATE TABLE `documentos` (
`id` int(11) NOT NULL auto_increment,
`descripcion` varchar(255) DEFAULT NULL,
`archivo` varchar(255) DEFAULT NULL,
`texto` text DEFAULT NULL,
`fec_carge` date DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10;

-- --------------------------------------------------------

-- 
-- Table structure for table `domicilios` 
-- 

DROP TABLE IF EXISTS `domicilios`;
CREATE TABLE `domicilios` (
`id` int(11) NOT NULL auto_increment,
`fecha` date DEFAULT NULL,
`domiciliario` varchar(255) DEFAULT NULL,
`cliente` varchar(255) DEFAULT NULL,
`cliente_fk` varchar(255) DEFAULT NULL,
`efectivo` varchar(255) DEFAULT NULL,
`factura` varchar(255) DEFAULT NULL,
`destino` varchar(255) DEFAULT NULL,
`guia` varchar(255) DEFAULT NULL,
`observacion` varchar(255) DEFAULT NULL,
`tipo` int(11) DEFAULT NULL,
`valor1` varchar(255) DEFAULT NULL,
`valor2` varchar(255) DEFAULT NULL,
`transportadora` varchar(255) DEFAULT NULL,
`estado` int(11) DEFAULT NULL,
`sede` int(11) DEFAULT NULL,
`efec1` int(11) DEFAULT NULL,
`efec2` int(11) DEFAULT NULL,
`efec3` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8930;

-- --------------------------------------------------------

-- 
-- Table structure for table `email_enviados` 
-- 

DROP TABLE IF EXISTS `email_enviados`;
CREATE TABLE `email_enviados` (
`id` int(11) NOT NULL auto_increment,
`usuario_id` int(11) NOT NULL,
`campana` int(11) NOT NULL,
`fecha` datetime NOT NULL,
`validado` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_email_enviados_usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1122;

-- --------------------------------------------------------

-- 
-- Table structure for table `emailtracker` 
-- 

DROP TABLE IF EXISTS `emailtracker`;
CREATE TABLE `emailtracker` (
`id` int(11) NOT NULL auto_increment,
`usuario_id` int(10) DEFAULT NULL,
`ip` varchar(50) DEFAULT NULL,
`descripcion` varchar(50) DEFAULT NULL,
`fecha` datetime DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `timestamp` (`fecha`)
) ENGINE=InnoDB AUTO_INCREMENT=505;

-- --------------------------------------------------------

-- 
-- Table structure for table `empresas_domicilios` 
-- 

DROP TABLE IF EXISTS `empresas_domicilios`;
CREATE TABLE `empresas_domicilios` (
`id` int(11) NOT NULL auto_increment,
`nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12;

-- --------------------------------------------------------

-- 
-- Table structure for table `especialidades` 
-- 

DROP TABLE IF EXISTS `especialidades`;
CREATE TABLE `especialidades` (
`id` int(11) NOT NULL auto_increment,
`descripcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24;

-- --------------------------------------------------------

-- 
-- Table structure for table `laboratorios` 
-- 

DROP TABLE IF EXISTS `laboratorios`;
CREATE TABLE `laboratorios` (
`id` int(11) NOT NULL auto_increment,
`nomlaboratorio` varchar(255) DEFAULT NULL,
`imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15;

-- --------------------------------------------------------

-- 
-- Table structure for table `literaturas` 
-- 

DROP TABLE IF EXISTS `literaturas`;
CREATE TABLE `literaturas` (
`id` int(11) NOT NULL auto_increment,
`descripcion` varchar(255) DEFAULT NULL,
`estado` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62;

-- --------------------------------------------------------

-- 
-- Table structure for table `medicos` 
-- 

DROP TABLE IF EXISTS `medicos`;
CREATE TABLE `medicos` (
`id` int(11) NOT NULL auto_increment,
`usuario_id` int(11) NOT NULL,
`especialidad` int(11) DEFAULT NULL,
`zona` int(11) DEFAULT NULL,
`dir` varchar(255) DEFAULT NULL,
`ciudaddir1` int(11) DEFAULT NULL,
`barrio1` varchar(255) DEFAULT NULL,
`dir2` varchar(255) DEFAULT NULL,
`ciudaddir2` int(11) DEFAULT NULL,
`barrio2` varchar(255) DEFAULT NULL,
`ciudad` int(11) DEFAULT NULL,
`tel1` varchar(255) DEFAULT NULL,
`tel2` varchar(255) DEFAULT NULL,
`cel1` varchar(255) DEFAULT NULL,
`cel2` varchar(255) DEFAULT NULL,
`mes_cum` int(11) DEFAULT NULL,
`dia_cum` int(11) DEFAULT NULL,
`hor` varchar(255) DEFAULT NULL,
`hijos` int(11) DEFAULT NULL,
`mail` varchar(255) DEFAULT NULL,
`genero` char(1) DEFAULT NULL,
`contacto` varchar(255) DEFAULT NULL,
`con_dia` int(11) DEFAULT NULL,
`con_mes` int(11) DEFAULT NULL,
`cond` text DEFAULT NULL,
`hobby` text DEFAULT NULL,
`observacion` text DEFAULT NULL,
`proyecto` text DEFAULT NULL,
`directorio` int(11) DEFAULT '0',
`univ_egresado` varchar(255) DEFAULT NULL,
`titulo` varchar(255) DEFAULT NULL,
`especializacion` varchar(255) DEFAULT NULL,
`especializacion2` varchar(255) DEFAULT NULL,
`especializacion3` varchar(255) DEFAULT NULL,
`univ_especial` varchar(255) DEFAULT NULL,
`univ_especial2` varchar(255) DEFAULT NULL,
`univ_especial3` varchar(255) DEFAULT NULL,
`resena` text DEFAULT NULL,
`fecha_ult_vis` date DEFAULT NULL,
`per_edit` varchar(255) DEFAULT NULL,
`fec_act` date DEFAULT NULL,
`fechaCreacion` date DEFAULT NULL,
`habilitado` int(11) DEFAULT '1',
`saldoPrepago` int(11) DEFAULT '0',
`saldoEfectivo` int(11) DEFAULT '0',
`tipo_cliente_celebre` int(11) DEFAULT '5',
`listaPrecios` int(11) DEFAULT '0',
`cliente_nuevo` int(11) DEFAULT '0',
`cliente_especial` int(11) DEFAULT '0',
`cliente_descuento` int(11) DEFAULT '0',
`fec_ult_pedido` date DEFAULT NULL,
`valor_compras` int(11) DEFAULT NULL,
`mes_compras` int(11) DEFAULT NULL,
`ano_compras` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_medicos_especialidades` (`especialidad`),
  KEY `FK_medicos_usuarios` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3451;

-- --------------------------------------------------------

-- 
-- Table structure for table `movimientos` 
-- 

DROP TABLE IF EXISTS `movimientos`;
CREATE TABLE `movimientos` (
`id` int(11) NOT NULL auto_increment,
`medico` int(11) NOT NULL,
`des_mov` text DEFAULT NULL,
`fecha` date DEFAULT NULL,
`hora` time DEFAULT NULL,
`tipoMov` int(11) DEFAULT NULL,
`valMov` int(11) DEFAULT NULL,
`bonificacion` int(11) DEFAULT NULL,
`usuarioRegistra` int(11) DEFAULT NULL,
`tipoSaldo` int(11) DEFAULT NULL,
`referencia` int(11) DEFAULT NULL,
`saldo_efectivo` int(11) DEFAULT NULL,
`saldo_credito` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `medico` (`medico`),
  KEY `FK_movimientos_usuarios_2` (`usuarioRegistra`)
) ENGINE=InnoDB AUTO_INCREMENT=7890;

-- --------------------------------------------------------

-- 
-- Table structure for table `municipios` 
-- 

DROP TABLE IF EXISTS `municipios`;
CREATE TABLE `municipios` (
`id` varchar(11) NOT NULL,
`nombreMunicipio` varchar(255) NOT NULL,
`departamento_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_municipios_departamentos` (`departamento_id`)
) ENGINE=InnoDB;

-- --------------------------------------------------------

-- 
-- Table structure for table `noticias` 
-- 

DROP TABLE IF EXISTS `noticias`;
CREATE TABLE `noticias` (
`id` int(10) NOT NULL auto_increment,
`fecha` varchar(100) DEFAULT NULL,
`titulo` varchar(100) DEFAULT NULL,
`texto` text DEFAULT NULL,
`categoria_fk` int(11) NOT NULL,
`imagen` varchar(255) DEFAULT NULL,
`fuente` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44;

-- --------------------------------------------------------

-- 
-- Table structure for table `noticias_cat` 
-- 

DROP TABLE IF EXISTS `noticias_cat`;
CREATE TABLE `noticias_cat` (
`id` int(11) NOT NULL auto_increment,
`nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10;

-- --------------------------------------------------------

-- 
-- Table structure for table `noticias_minisitio` 
-- 

DROP TABLE IF EXISTS `noticias_minisitio`;
CREATE TABLE `noticias_minisitio` (
`id` int(10) NOT NULL auto_increment,
`fecha` varchar(100) DEFAULT NULL,
`titulo` varchar(100) DEFAULT NULL,
`texto` text DEFAULT NULL,
`imagen` varchar(255) DEFAULT NULL,
`fuente` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4;

-- --------------------------------------------------------

-- 
-- Table structure for table `obsequios` 
-- 

DROP TABLE IF EXISTS `obsequios`;
CREATE TABLE `obsequios` (
`id` int(11) NOT NULL auto_increment,
`descripcion` varchar(255) DEFAULT NULL,
`estado` int(11) DEFAULT '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30;

-- --------------------------------------------------------

-- 
-- Table structure for table `pedido_tmp` 
-- 

DROP TABLE IF EXISTS `pedido_tmp`;
CREATE TABLE `pedido_tmp` (
`id_tmp` int(11) NOT NULL auto_increment,
`id_producto` int(11) NOT NULL,
`cantidad_tmp` int(11) NOT NULL,
`precio_tmp` int(11) DEFAULT NULL,
`session_id` varchar(255) NOT NULL,
  PRIMARY KEY  (`id_tmp`)
) ENGINE=InnoDB AUTO_INCREMENT=13629;

-- --------------------------------------------------------

-- 
-- Table structure for table `pedidos` 
-- 

DROP TABLE IF EXISTS `pedidos`;
CREATE TABLE `pedidos` (
`idpedido` int(10) unsigned NOT NULL auto_increment,
`usuario_idusuario` varchar(255) NOT NULL,
`estadopedido` int(11) NOT NULL,
`iva` int(11) DEFAULT NULL,
`total` int(11) DEFAULT NULL,
`descuento` int(11) DEFAULT NULL,
`fecpedido` datetime DEFAULT NULL,
`observacion` text DEFAULT NULL,
`usuarioRegistra` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`idpedido`),
  KEY `pedido_FKIndex1` (`usuario_idusuario`)
) ENGINE=InnoDB AUTO_INCREMENT=32990;

-- --------------------------------------------------------

-- 
-- Table structure for table `pedidos_productos` 
-- 

DROP TABLE IF EXISTS `pedidos_productos`;
CREATE TABLE `pedidos_productos` (
`idpedido_producto` int(10) unsigned NOT NULL auto_increment,
`producto_idproducto` int(5) unsigned NOT NULL,
`pedido_idpedido` int(10) unsigned NOT NULL,
`cantpedido_producto` int(5) unsigned NOT NULL,
`valproducto` int(11) unsigned NOT NULL,
`estado` int(11) DEFAULT '0',
  PRIMARY KEY  (`idpedido_producto`),
  KEY `pedido_producto_FKIndex1` (`pedido_idpedido`),
  KEY `pedido_producto_FKIndex2` (`producto_idproducto`)
) ENGINE=InnoDB AUTO_INCREMENT=129965;

-- --------------------------------------------------------

-- 
-- Table structure for table `permisos` 
-- 

DROP TABLE IF EXISTS `permisos`;
CREATE TABLE `permisos` (
`id` int(5) unsigned NOT NULL auto_increment,
`nompermiso` varchar(200) NOT NULL,
`catpermiso` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1002;

-- --------------------------------------------------------

-- 
-- Table structure for table `permisos_roles` 
-- 

DROP TABLE IF EXISTS `permisos_roles`;
CREATE TABLE `permisos_roles` (
`id` int(5) unsigned NOT NULL auto_increment,
`permiso_id` int(5) unsigned NOT NULL,
`rol_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `permiso_rol_FKIndex1` (`rol_id`),
  KEY `permiso_rol_FKIndex2` (`permiso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6867;

-- --------------------------------------------------------

-- 
-- Table structure for table `porcentajes_crecimiento` 
-- 

DROP TABLE IF EXISTS `porcentajes_crecimiento`;
CREATE TABLE `porcentajes_crecimiento` (
`id` int(11) NOT NULL auto_increment,
`zona` int(11) DEFAULT NULL,
`porcentaje` int(3) DEFAULT '0',
`pesos` int(11) DEFAULT '0',
`mes` int(11) DEFAULT NULL,
`ano` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1578;

-- --------------------------------------------------------

-- 
-- Table structure for table `premios` 
-- 

DROP TABLE IF EXISTS `premios`;
CREATE TABLE `premios` (
`id` int(11) NOT NULL auto_increment,
`despremio` varchar(255) NOT NULL,
`puntos` int(11) NOT NULL,
`estado` int(11) NOT NULL,
`imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10;

-- --------------------------------------------------------

-- 
-- Table structure for table `premios_redimidos` 
-- 

DROP TABLE IF EXISTS `premios_redimidos`;
CREATE TABLE `premios_redimidos` (
`id` int(11) NOT NULL auto_increment,
`usuario_fk` varchar(255) DEFAULT NULL,
`premio_fk` int(11) DEFAULT '0',
`puntos_redimidos` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13;

-- --------------------------------------------------------

-- 
-- Table structure for table `productos` 
-- 

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
`idproducto` int(5) unsigned NOT NULL auto_increment,
`categoria_idcategoria` int(5) unsigned NOT NULL,
`linea` int(11) DEFAULT NULL,
`origen` int(11) DEFAULT NULL,
`laboratorio` int(11) DEFAULT NULL,
`formafarmaceutica` varchar(255) DEFAULT NULL,
`desproducto` varchar(255) NOT NULL,
`valproducto` int(11) unsigned NOT NULL,
`valproducto2` int(11) unsigned NOT NULL,
`valproducto3` int(11) unsigned NOT NULL,
`valproducto4` int(11) unsigned NOT NULL,
`valproducto5` int(11) unsigned NOT NULL,
`valproducto6` int(11) unsigned NOT NULL,
`valproducto7` int(11) unsigned NOT NULL,
`valproducto8` int(11) unsigned NOT NULL,
`valproducto_anti` int(11) unsigned DEFAULT '0',
`rutproducto` varchar(250) NOT NULL,
`promocion` int(1) NOT NULL,
`agotado` int(1) unsigned DEFAULT '0',
`oculto` int(1) unsigned DEFAULT '0',
`destacado` int(11) unsigned DEFAULT NULL,
`meta_producto` int(11) unsigned DEFAULT '0',
`recomendados` varchar(255) DEFAULT NULL,
`descripcion1` text DEFAULT NULL,
`descripcion2` text DEFAULT NULL,
`descripcion3` text DEFAULT NULL,
`descripcion4` text DEFAULT NULL,
`descripcion5` text DEFAULT NULL,
`descripcion6` text DEFAULT NULL,
`descripcion7` text DEFAULT NULL,
`descripcion8` text DEFAULT NULL,
`h1` varchar(255) DEFAULT NULL,
`h2` varchar(255) DEFAULT NULL,
`h3` varchar(255) DEFAULT NULL,
`h4` varchar(255) DEFAULT NULL,
`h5` varchar(255) DEFAULT NULL,
`h6` varchar(255) DEFAULT NULL,
`title` varchar(255) DEFAULT NULL,
`description` varchar(255) DEFAULT NULL,
`visitas` int(11) DEFAULT '0',
`archivo` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`idproducto`),
  KEY `producto_FKIndex1` (`categoria_idcategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=580;

-- --------------------------------------------------------

-- 
-- Table structure for table `roles` 
-- 

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
`id` int(11) unsigned NOT NULL auto_increment,
`nomrol` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `rol_UNIQUE1` (`nomrol`)
) ENGINE=InnoDB AUTO_INCREMENT=11;

-- --------------------------------------------------------

-- 
-- Table structure for table `tabla_beneficios` 
-- 

DROP TABLE IF EXISTS `tabla_beneficios`;
CREATE TABLE `tabla_beneficios` (
`id` int(11) NOT NULL auto_increment,
`orden` int(11) DEFAULT NULL,
`rango1` int(11) DEFAULT NULL,
`rango2` int(11) DEFAULT NULL,
`descuento_r1` float(3,1) DEFAULT NULL,
`rango3` int(11) DEFAULT NULL,
`rango4` int(11) DEFAULT NULL,
`descuento_r2` float(3,1) DEFAULT NULL,
`rango5` int(11) DEFAULT NULL,
`rango6` int(11) DEFAULT NULL,
`descuento_r3` float(3,1) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1;

-- --------------------------------------------------------

-- 
-- Table structure for table `tabla_cierre_cli_celebres` 
-- 

DROP TABLE IF EXISTS `tabla_cierre_cli_celebres`;
CREATE TABLE `tabla_cierre_cli_celebres` (
`id` int(11) NOT NULL auto_increment,
`medico` varchar(255) NOT NULL,
`zona` int(11) NOT NULL,
`cliente_celebre` int(11) NOT NULL,
`rango1` int(11) NOT NULL,
`rango2` int(11) NOT NULL,
`compras` int(11) NOT NULL,
`bono` int(11) NOT NULL,
`trimestre` int(11) NOT NULL,
`ano` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_tabla_cierre_cli_celebres_medicos` (`medico`)
) ENGINE=InnoDB AUTO_INCREMENT=306;

-- --------------------------------------------------------

-- 
-- Table structure for table `tabla_descuentos` 
-- 

DROP TABLE IF EXISTS `tabla_descuentos`;
CREATE TABLE `tabla_descuentos` (
`id` int(11) NOT NULL,
`rango1` int(11) unsigned DEFAULT NULL,
`rango2` int(11) unsigned DEFAULT NULL,
`descuento1` float(4,2) DEFAULT NULL,
`rango3` int(11) unsigned DEFAULT NULL,
`descuento2` float(4,2) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB;

-- --------------------------------------------------------

-- 
-- Table structure for table `tabla_info_prod_mes` 
-- 

DROP TABLE IF EXISTS `tabla_info_prod_mes`;
CREATE TABLE `tabla_info_prod_mes` (
`id` int(11) unsigned NOT NULL auto_increment,
`producto` int(11) unsigned NOT NULL,
`meta` int(11) unsigned NOT NULL,
`ano` int(11) unsigned NOT NULL,
`mes` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_tabla_info_prod_mes_productos` (`producto`)
) ENGINE=InnoDB AUTO_INCREMENT=195;

-- --------------------------------------------------------

-- 
-- Table structure for table `tabla_valores_cli_celebres` 
-- 

DROP TABLE IF EXISTS `tabla_valores_cli_celebres`;
CREATE TABLE `tabla_valores_cli_celebres` (
`id` int(11) NOT NULL auto_increment,
`ano` int(11) DEFAULT NULL,
`porcentaje1` float(3,1) DEFAULT '0.0',
`porcentaje2` float(3,1) DEFAULT '0.0',
`cat1_1` int(11) DEFAULT NULL,
`cat1_2` int(11) DEFAULT NULL,
`cat2_1` int(11) DEFAULT NULL,
`cat2_2` int(11) DEFAULT NULL,
`cat3_1` int(11) DEFAULT NULL,
`cat3_2` int(11) DEFAULT NULL,
`cat4_1` int(11) DEFAULT NULL,
`cat4_2` int(11) DEFAULT NULL,
`cat5_1` int(11) DEFAULT NULL,
`cat5_2` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2;

-- --------------------------------------------------------

-- 
-- Table structure for table `texto_correos` 
-- 

DROP TABLE IF EXISTS `texto_correos`;
CREATE TABLE `texto_correos` (
`id` int(11) NOT NULL,
`descripcion` varchar(50) NOT NULL,
`texto` text DEFAULT NULL
) ENGINE=InnoDB;

-- --------------------------------------------------------

-- 
-- Table structure for table `tipo_contactos` 
-- 

DROP TABLE IF EXISTS `tipo_contactos`;
CREATE TABLE `tipo_contactos` (
`id` int(11) NOT NULL auto_increment,
`descripcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6;

-- --------------------------------------------------------

-- 
-- Table structure for table `tipos_documentos` 
-- 

DROP TABLE IF EXISTS `tipos_documentos`;
CREATE TABLE `tipos_documentos` (
`id` int(11) NOT NULL auto_increment,
`tipo` varchar(80) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6;

-- --------------------------------------------------------

-- 
-- Table structure for table `usuarios` 
-- 

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
`id` int(11) NOT NULL auto_increment,
`tipo_documento` int(11) DEFAULT NULL,
`documento` varchar(255) DEFAULT '0',
`nom` varchar(255) NOT NULL,
`ape1` varchar(255) DEFAULT NULL,
`ape2` varchar(255) DEFAULT NULL,
`dir` varchar(255) DEFAULT NULL,
`barrio` varchar(255) DEFAULT NULL,
`tel` varchar(200) DEFAULT NULL,
`cel` varchar(200) DEFAULT NULL,
`mail` varchar(255) DEFAULT NULL,
`usu` varchar(255) DEFAULT '',
`avatar` varchar(255) DEFAULT '',
`pass` varchar(255) DEFAULT '',
`ciudad_actual` int(11) unsigned DEFAULT NULL,
`idrol` int(11) unsigned NOT NULL,
`estado` int(11) unsigned NOT NULL,
`cuenta_activa` int(11) unsigned NOT NULL,
`fecha_activa_cuenta` date DEFAULT NULL,
`fec_nac` date DEFAULT NULL,
`puntos` int(11) DEFAULT '0',
`ciudad_nomina` int(4) DEFAULT NULL,
`cambiar_fecha_visita` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `rol_personal_ibfk_1` (`idrol`),
  KEY `tipo_documento` (`tipo_documento`)
) ENGINE=InnoDB AUTO_INCREMENT=2994;

-- --------------------------------------------------------

-- 
-- Table structure for table `videos` 
-- 

DROP TABLE IF EXISTS `videos`;
CREATE TABLE `videos` (
`id` int(11) NOT NULL auto_increment,
`nombre` varchar(255) NOT NULL,
`imagen` varchar(255) NOT NULL,
`video` varchar(255) NOT NULL,
`tipo` int(11) NOT NULL,
`medico` varchar(150) NOT NULL,
`descripcion` text NOT NULL,
`fecha_carga` date NOT NULL,
`estado` int(11) DEFAULT '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12;

-- --------------------------------------------------------

-- 
-- Table structure for table `visitas` 
-- 

DROP TABLE IF EXISTS `visitas`;
CREATE TABLE `visitas` (
`id` int(11) NOT NULL auto_increment,
`usuario_id` int(11) NOT NULL,
`fecha` date DEFAULT NULL,
`hora` time NOT NULL DEFAULT '00:00:00',
`literatura` varchar(255) DEFAULT NULL,
`obsequios` varchar(255) DEFAULT NULL,
`muestra` varchar(255) DEFAULT NULL,
`observacion` text DEFAULT NULL,
`accion` text DEFAULT NULL,
`id_vendedor` varchar(255) DEFAULT NULL,
`contacto` int(11) DEFAULT NULL,
`comentario` longtext DEFAULT NULL,
`estado` int(11) DEFAULT '0',
`usuario_id_com` int(11) DEFAULT '0',
`estado_com` int(11) DEFAULT '0',
`fecha_ver_com` datetime DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `medico` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22397;

-- --------------------------------------------------------

-- 
-- Table structure for table `visitas_no_realizadas` 
-- 

DROP TABLE IF EXISTS `visitas_no_realizadas`;
CREATE TABLE `visitas_no_realizadas` (
`id` int(11) NOT NULL auto_increment,
`cliente` varchar(255) DEFAULT NULL,
`mes` int(11) DEFAULT NULL,
`ano` int(11) DEFAULT NULL,
`comentario` text DEFAULT NULL,
`compromiso` text DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_visitas_no_realizadas_medicos` (`cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=123;

-- --------------------------------------------------------

-- 
-- Table structure for table `zonas` 
-- 

DROP TABLE IF EXISTS `zonas`;
CREATE TABLE `zonas` (
`id` int(11) NOT NULL auto_increment,
`des` varchar(255) DEFAULT NULL,
`id_vendedor` int(11) DEFAULT '0',
`linea` int(11) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `id_vendedor_fk` (`id_vendedor`)
) ENGINE=InnoDB AUTO_INCREMENT=17;

-- --------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 1;

-- ------------
-- FOREIGN KEYS
-- ------------
SET FOREIGN_KEY_CHECKS = 0;

ALTER TABLE `bitacora_acceso` ADD CONSTRAINT `FK_bitacora_acceso_usuarios` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `casos_clinicos_ayudas` ADD CONSTRAINT `casos_clinicos_ayudas_ibfk_1` FOREIGN KEY (`caso_fk`) REFERENCES `casos_clinicos` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `email_enviados` ADD CONSTRAINT `FK_email_enviados_usuarios` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `medicos` ADD CONSTRAINT `FK_medicos_especialidades` FOREIGN KEY (`especialidad`) REFERENCES `especialidades` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `medicos` ADD CONSTRAINT `FK_medicos_usuarios` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `movimientos` ADD CONSTRAINT `FK_movimientos_usuarios` FOREIGN KEY (`medico`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `movimientos` ADD CONSTRAINT `FK_movimientos_usuarios_2` FOREIGN KEY (`usuarioRegistra`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `municipios` ADD CONSTRAINT `FK_municipios_departamentos` FOREIGN KEY (`departamento_id`) REFERENCES `departamentos` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `permisos_roles` ADD CONSTRAINT `permisos_roles_ibfk_3` FOREIGN KEY (`permiso_id`) REFERENCES `permisos` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `tabla_info_prod_mes` ADD CONSTRAINT `FK_tabla_info_prod_mes_productos` FOREIGN KEY (`producto`) REFERENCES `productos` (`idproducto`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `usuarios` ADD CONSTRAINT `FK_usuarios_tipos_documentos` FOREIGN KEY (`tipo_documento`) REFERENCES `tipos_documentos` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `usuarios` ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`idrol`) REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `visitas` ADD CONSTRAINT `FK_visitas_usuarios` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `zonas` ADD CONSTRAINT `FK_zonas_usuarios` FOREIGN KEY (`id_vendedor`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

SET FOREIGN_KEY_CHECKS = 1;

